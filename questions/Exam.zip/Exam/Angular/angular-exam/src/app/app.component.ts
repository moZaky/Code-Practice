import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  //books = [{ id: 1, name: 'First book' }];
  books: any = [];

  bookForm = new FormGroup({
    id: new FormControl(''),
    name: new FormControl('', Validators.required),
  });

  addBook() {
    if (this.bookForm.valid) {
      let bookName = this.bookForm.value.name!;
      let newId = 0;
      if (this.books.length == 0) {
        newId = 0;
      } else {
        newId = this.books[this.books.length - 1].id + 1;
      }

      this.books.push({ id: newId, name: bookName });
      this.bookForm.reset();
    }
  }

  deleteBook(bookId: number) {
    this.books.splice(
      this.books.findIndex((a: any) => a.id === bookId),
      1
    );
  }
}
