﻿using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Collections.Generic;

namespace BankingApp.services
{
    public class BankingService : IBankingService
    {
        static readonly object _object = new object();

        private Dictionary<int, double> _accounts = new Dictionary<int, double>();

        public BankingService(double[] accounts)
        {
            for (int i = 0; i < accounts.Count(); i++)
            {
                _accounts[i] = accounts[i];
            }

        }

        public double GetBalance(int accountId)
        {
            return _accounts[accountId];

        }

        public void Withdraw(int accountId, double amount)
        {
            if(amount <= 0)
            {
                throw new ArgumentException("Wroung amount");
            }

            if (_accounts.ContainsKey(accountId))
            {
                if (_accounts[accountId] < amount)
                {
                    throw new ArgumentException("Not suficient amount");
                }
                lock (_object)
                {
                    _accounts[accountId] -= amount;
                }
            }
            else
            {
                throw new ArgumentException("account not exsist");
            }
        }

        public void Deposit(int accountId, double amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Wroung amount");
            }

            if (_accounts.ContainsKey(accountId))
            {
                lock (_object)
                {
                    _accounts[accountId] += amount;
                }
            }
            else
            {
                throw new ArgumentException("account not exsist");
            }
        }

    }
}
