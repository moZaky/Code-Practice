﻿namespace BankingApp.services
{
    public interface IBankingService
    {

        double GetBalance(int accountId);
        void Withdraw(int accountId, double amount);
        void Deposit(int accountId, double amount);
    }
}
